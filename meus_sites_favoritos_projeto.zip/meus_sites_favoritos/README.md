# Meus sites favoritos

Projeto de página web desenvolvido em HTML e CSS.

## Como executar
1. Extraia a pasta `meus_sites_favoritos`.
2. Mantenha o arquivo `index.html` e a pasta `imagens` no mesmo diretório.
3. Abra `index.html` com dois cliques ou pelo navegador.

## Sites incluídos
- Google — https://www.google.com
- YouTube — https://www.youtube.com
- GitHub — https://github.com
- W3Schools — https://www.w3schools.com
- ChatGPT — https://chatgpt.com

## Personalização
Edite o texto do título no arquivo `index.html` para trocar o nome, e altere os nomes, endereços e imagens conforme seus próprios favoritos.

As imagens da pasta `imagens` são ilustrações locais criadas para este projeto. Os links levam aos sites oficiais.

## Publicar no GitHub
1. Entre em https://github.com e faça login.
2. Clique em **New repository**.
3. Dê o nome `meus-sites-favoritos` e crie o repositório.
4. Envie o arquivo `index.html`, a pasta `imagens` e este `README.md` (ou use GitHub Desktop).
5. Para publicar como site, abra **Settings → Pages**, selecione a branch `main` e a pasta `/ (root)`, e salve.
